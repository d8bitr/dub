
                              README

            The JGoodies Forms Demo Binary Version 1.0.5 


INTRODUCTION

     This demo application utilizes and presents the JGoodies Forms, 
     a framework that helps you layout and implement Swing panels 
     quickly, consistently and in a high quality. 
     
     Forms consists of a layout manager, builder classes that 
     fill panels and factories that speed up the UI construction.
     You can find more information about the JGoodies Forms at
         http://www.JGoodies.com/freeware/forms/ 
     And you can download additional sample applications from 
         http://www.JGoodies.com/freeware/.
     
     The JGoodies Forms and this demo require Java 1.4 or later.
     

DISTRIBUTION CONTENTS

     The Forms Demo binary distribution contains:
       o LICENSE.txt         - the binary license agreement 
       o README.txt          - this readme file
       o RELEASE-NOTES.txt   - information about changes, bug fixes, etc.
       o formsdemo-1.0.5.jar - the executable JAR for the application
     
     
Copyright (c) 2002-2005 JGoodies Karsten Lentzsch. All rights reserved.