
                              README

            The JGoodies Looks Demo Binary Version 1.3.1


INTRODUCTION

     This application demos the JGoodies Windows Look&Feel and the 
     Plastic Look&Feel family. These looks have been optimized for 
     readability, precise layout, and more generally, usability 
      - nevertheless many people have reviewed them as elegant.

     The Looks Demo consists of three parts: 
        1) In the Launcher select the look, color theme and options.
        2) The Demo frame shows the effects of the current settings.
        3) The Help describes the launcher settings and their effects.
     
     Since version 1.2 the Looks and this demo require Java 1.4 or later.


DISTRIBUTION CONTENTS

     The Looks Demo binary distribution contains:
       o LICENSE.txt          - the binary license agreement 
       o README.txt           - this readme file
       o RELEASE-NOTES.txt    - information about changes, bug fixes, etc.
       o looksdemo-1.3.1.jar  - the executable JAR for the application
       
     
Copyright (c) 2002-2005 JGoodies Karsten Lentzsch. All rights reserved.